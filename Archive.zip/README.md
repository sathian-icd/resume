#resume.s
This repository belongs to Sathian M.
This repository is created under /sathian-icd/resume.s on 03/04/2020 in the order of dd/mm/yyyy
and this is also a hosted website under github.io in the address https://sathian-icd.github.io/resume.s/
the objective of this repository is a create a Professional resume for a college project of Amrita School of Engineering, Bangalore in User-design interface class.
This project uses HTML, CSS and Bootstrap.
